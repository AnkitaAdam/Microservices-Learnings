package com.microservices.admin_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

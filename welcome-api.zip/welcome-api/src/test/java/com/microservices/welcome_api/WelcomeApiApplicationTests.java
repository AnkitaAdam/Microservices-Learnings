package com.microservices.welcome_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelcomeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
